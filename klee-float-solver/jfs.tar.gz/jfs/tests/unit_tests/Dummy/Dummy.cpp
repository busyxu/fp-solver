#include "gtest/gtest.h"

TEST(Dummy, DummyOne) {
  EXPECT_EQ(1, 1);
}
