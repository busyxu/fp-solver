The DummyFuzzingSolver doesn't try to fuzz so
in effect this tests how well the pre-processing
steps are able to make queries trivially sat/unsat.
