These tests are intended to bypass JFS's optimisation passes to perform
basic testing of loading models from a LibFuzzer input.

This rather crude and we need to come up with a better way of testing
this component of JFS.
