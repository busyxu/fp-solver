//===----------------------------------------------------------------------===//
//
//                                     JFS
//
// Copyright 2017-2018 Daniel Liew
//
// This file is distributed under the MIT license.
// See LICENSE.txt for details.
//
//===----------------------------------------------------------------------===//
#include "jfs/CXXFuzzingBackend/CXXProgramBuilderOptions.h"

namespace jfs {
namespace cxxfb {
CXXProgramBuilderOptions::CXXProgramBuilderOptions() {}
} // namespace cxxfb
} // namespace jfs
