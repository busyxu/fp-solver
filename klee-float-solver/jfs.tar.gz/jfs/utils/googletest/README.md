This is googletest 1.8.0
