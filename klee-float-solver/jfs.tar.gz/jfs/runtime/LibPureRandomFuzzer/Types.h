//===----------------------------------------------------------------------===//
//
//                                     JFS
//
// Copyright 2018 J. Ryan Stinnett
//
// This file is distributed under the MIT license.
// See LICENSE.txt for details.
//
//===----------------------------------------------------------------------===//

#ifndef PRF_TYPES_H
#define PRF_TYPES_H

namespace prf {

typedef unsigned int uint;

} // prf

#endif // PRF_TYPES_H