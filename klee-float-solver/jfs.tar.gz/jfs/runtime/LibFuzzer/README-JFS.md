# LibFuzzer

This is a copy of LibFuzzer from the LLVM 6.0 SVN (prior to 6.0 release)

This is at

SVN: r321544
git-svn: 803a9a0208b46cff21135c1a81b53b2b6cc54ea6

but it is patched with features that JFS needs. We should
upstream these at some point.

# Why are you embedding your own copy!? You MONSTER!

This is an early research project. We needed to modify
LibFuzzer to suit our needs.
